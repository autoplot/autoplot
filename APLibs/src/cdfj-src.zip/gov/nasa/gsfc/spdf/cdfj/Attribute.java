package gov.nasa.gsfc.spdf.cdfj;
import java.util.*;
/**
 *  CDF Attribute specification
 */
public interface Attribute {
    public String getName();
    public boolean isGlobal();
}
