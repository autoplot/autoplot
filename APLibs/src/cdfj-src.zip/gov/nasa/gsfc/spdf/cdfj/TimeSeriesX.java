package gov.nasa.gsfc.spdf.cdfj;
public interface TimeSeriesX extends TimeSeries {
    public boolean isOneD();
    public boolean isColumnMajor();
}
